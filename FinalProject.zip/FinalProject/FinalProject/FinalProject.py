# ************************************
# Python Snake
# ************************************
from tkinter import *
from tkinter import Toplevel
from tkinter import messagebox
import random
import time


GAME_WIDTH = 700
GAME_HEIGHT = 700
SPEED = 100
SPACE_SIZE = 50
BODY_PARTS = 3
SNAKE_COLOR = "#0000FF"
FOOD_COLOR = "#FF0000"
BACKGROUND_COLOR = "#000000"


class Snake:
    # creating the snake object 

    def __init__(self):
        self.body_size = BODY_PARTS
        self.coordinates = []
        self.squares = []

        for i in range(0, BODY_PARTS):
            self.coordinates.append([0, 0])

        for x, y in self.coordinates:
            square = canvas.create_rectangle(x, y, x + SPACE_SIZE, y + SPACE_SIZE, fill=SNAKE_COLOR, tag="snake")
            self.squares.append(square)


class Food:
    # creating the food object

    def __init__(self):
        self.spawn()

    def spawn(self):
        x = random.randint(0, (GAME_WIDTH / SPACE_SIZE)-1) * SPACE_SIZE
        y = random.randint(0, (GAME_HEIGHT / SPACE_SIZE) - 1) * SPACE_SIZE

        self.coordinates = [x, y]

        canvas.create_rectangle(x, y, x + SPACE_SIZE, y + SPACE_SIZE, fill=FOOD_COLOR, tag="food")


def next_turn(snake, food):
    # defining what happens when the snake changes directions


    x, y = snake.coordinates[0]

    if direction == "up":
        y -= SPACE_SIZE
    elif direction == "down":
        y += SPACE_SIZE
    elif direction == "left":
        x -= SPACE_SIZE
    elif direction == "right":
        x += SPACE_SIZE

    snake.coordinates.insert(0, (x, y))

    square = canvas.create_rectangle(x, y, x + SPACE_SIZE, y + SPACE_SIZE, fill=SNAKE_COLOR)

    snake.squares.insert(0, square)

    if x == food.coordinates[0] and y == food.coordinates[1]:

        global score

        score += 1

        label.config(text="Score:{}".format(score))

        canvas.delete("food")

        food = Food()

    else:

        del snake.coordinates[-1]

        canvas.delete(snake.squares[-1])

        del snake.squares[-1]

    if check_collisions(snake):
        game_over()

    else:
        window.after(SPEED, next_turn, snake, food)


def change_direction(new_direction):
    # defining how to make the snake change directions

    global direction

    if new_direction == 'left':
        if direction != 'right':
            direction = new_direction
    elif new_direction == 'right':
        if direction != 'left':
            direction = new_direction
    elif new_direction == 'up':
        if direction != 'down':
            direction = new_direction
    elif new_direction == 'down':
        if direction != 'up':
            direction = new_direction


def check_collisions(snake):
    # add the ability to detect collisions with the snake

    x, y = snake.coordinates[0]

    if x < 0 or x >= GAME_WIDTH:
        return True
    elif y < 0 or y >= GAME_HEIGHT:
        return True

    for body_part in snake.coordinates[1:]:
        if x == body_part[0] and y == body_part[1]:
            return True

    return False

def reset_game():

    global snake, food, score, direction

    time.sleep(2)

    snake = Snake()
    food = Food()
    score = 0
    direction = 'down'
    label.config(text="Score:{}".format(score))
    canvas.delete(ALL)

def start_game():
    global score, snake, food, direction, game_over
    global splash_screen

    time.sleep(2)

    score = 0
    # Disable game controls and key bindings
    canvas.unbind("<Left>")
    canvas.unbind("<Right>")
    canvas.unbind("<Up>")
    canvas.unbind("<Down>")
    # Destroy the splash screen
    splash_screen.destroy()
    # Set up game environment
    snake = Snake()
    food = Food()
    # Set up game controls and key bindings
    window.bind('<Left>', lambda event: change_direction('left'))
    window.bind('<Right>', lambda event: change_direction('right'))
    window.bind('<Up>', lambda event: change_direction('up'))
    window.bind('<Down>', lambda event: change_direction('down'))
    # Start the game loop
    next_turn(snake, food)
    window.mainloop()





def game_over():
    answer = messagebox.askyesno("Game Over", "Do you want to play again?")
    if answer:
        global score, direction
        score = 0
        direction = 'down'
        label.config(text="Score:{}".format(score))
        canvas.delete("all")
        snake = Snake()
        food = Food()
        next_turn(snake, food)
    else:
        window.destroy()

def splash_screen():
    global splash_screen
    global start_button
    # Create the splash screen window
    splash_screen = Toplevel()
    splash_screen.title("Snake Game")
    splash_screen.geometry("400x300")
    # Center the splash screen window
    x = (splash_screen.winfo_screenwidth() - splash_screen.winfo_reqwidth()) / 2
    y = (splash_screen.winfo_screenheight() - splash_screen.winfo_reqheight()) / 2
    splash_screen.geometry("+%d+%d" % (x, y))
    # Create the start button
    start_button = Button(splash_screen, text="Start Game", command=start_game)
    start_button.pack(pady=50, anchor="n", side="bottom")
    start_button.lift()
    # Add the splash screen image
    image = PhotoImage(file="C:/Users/Admin/Desktop/Python Projects/FinalProject/snake.png")
    image = image.subsample(2)
    label = Label(splash_screen, image=image)
    label.image = image
    label.pack(pady=50)
    label.place(relx=0.5, rely=0.5, anchor=CENTER)
    label.lower()
    # Disable game controls and key bindings
    canvas.unbind("<Left>")
    canvas.unbind("<Right>")
    canvas.unbind("<Up>")
    canvas.unbind("<Down>")
    # Start the splash screen
    splash_screen.mainloop()




window = Tk()
window.title("Snake game")
window.resizable(False, False)

score = 0
direction = 'down'

label = Label(window, text="Score:{}".format(score), font=('consolas', 40))
label.pack()

canvas = Canvas(window, bg=BACKGROUND_COLOR, height=GAME_HEIGHT, width=GAME_WIDTH)
canvas.pack()

window.update()

window_width = window.winfo_width()
window_height = window.winfo_height()
screen_width = window.winfo_screenwidth()
screen_height = window.winfo_screenheight()

x = int((screen_width/2) - (window_width/2))
y = int((screen_height/2) - (window_height/2))

window.geometry(f"{window_width}x{window_height}+{x}+{y}")

window.bind('<Left>', lambda event: change_direction('left'))
window.bind('<Right>', lambda event: change_direction('right'))
window.bind('<Up>', lambda event: change_direction('up'))
window.bind('<Down>', lambda event: change_direction('down'))

splash_screen()

snake = Snake()
food = Food()

next_turn(snake, food)

window.mainloop()